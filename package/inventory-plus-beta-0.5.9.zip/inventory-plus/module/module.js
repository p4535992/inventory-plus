import { setApi } from "../main.js";
import API from "./api.js";
import CONSTANTS from "./constants.js";
import { InventoryPlus } from "./inventory-plus.js";
import { InventoryPlusFlags } from "./inventory-plus-models.js";
import { getCSSName, i18n, warn, i18nFormat, retrieveItemFromData, checkCompatible, showCurrencyTransferDialog, isAlt, showItemTransferDialog, error, delayedSort, sortedActors, getItemSorts, } from "./lib/lib.js";
export const initHooks = async () => {
    // registerSettings();
    // registerLibwrappers();
    // Hooks.once('socketlib.ready', registerSocket);
    // if (game.settings.get(CONSTANTS.MODULE_NAME, 'debugHooks')) {
    //   for (const hook of Object.values(HOOKS)) {
    //     if (typeof hook === 'string') {
    //       Hooks.on(hook, (...args) => debug(`Hook called: ${hook}`, ...args));
    //       debug(`Registered hook: ${hook}`);
    //     } else {
    //       for (const innerHook of Object.values(hook)) {
    //         Hooks.on(<string>innerHook, (...args) => debug(`Hook called: ${innerHook}`, ...args));
    //         debug(`Registered hook: ${innerHook}`);
    //       }
    //     }
    //   }
    // }
};
export const setupHooks = async () => {
    setApi(API);
};
export const readyHooks = async () => {
    // checkSystem();
    // registerHotkeys();
    // Hooks.callAll(HOOKS.READY);
    // Add any additional hooks if necessary
    //@ts-ignore
    libWrapper.register(CONSTANTS.MODULE_NAME, 'game.dnd5e.applications.ActorSheet5eCharacter.prototype.getData', function (wrapper, ...args) {
        const sheetData = wrapper(...args);
        // let app = this;
        const actor = this.actor;
        const newInventory = InventoryPlus.processInventory(this, actor, sheetData.inventory);
        sheetData.inventory = newInventory;
        const encumbrance5e = API.calculateWeightFromActor(actor);
        if (game.modules.get('variant-encumbrance-dnd5e')?.active &&
            game.settings.get(CONSTANTS.MODULE_NAME, 'enableIntegrationWithVariantEncumbrance')) {
            // DO NOTHING
        }
        else {
            if (!encumbrance5e) {
                sheetData.data.attributes.encumbrance = encumbrance5e;
            }
        }
        return sheetData;
    }, 'WRAPPER');
    //@ts-ignore
    libWrapper.register(CONSTANTS.MODULE_NAME, 'game.dnd5e.applications.ActorSheet5eCharacter.prototype._onDropItem', async function (wrapped, ...args) {
        const [event, data] = args;
        const actor = this.actor;
        const targetActor = actor;
        const itemTypeCurrent = data?.type; // || event.type;
        if (itemTypeCurrent != 'Item') {
            warn(i18n(`${CONSTANTS.MODULE_NAME}.dialogs.warn.itemtypecurrent`));
            return;
        }
        const itemId = data?.data?._id || data?.id; // || event.id || event.data?._id;
        if (!itemId) {
            warn(i18n(`${CONSTANTS.MODULE_NAME}.dialogs.warn.itemid`));
            return;
        }
        const dragAndDropFromCompendium = data.pack ? true : false;
        const dragAndDropFromActorSource = data.actorId ? true : false;
        const itemCurrent = await retrieveItemFromData(actor, itemId, '', data.pack, data.actorId);
        if (!itemCurrent) {
            warn(i18n(`${CONSTANTS.MODULE_NAME}.dialogs.warn.itemcurrent`));
            return;
        }
        const itemData = itemCurrent?.data;
        if (!itemData) {
            warn(i18n(`${CONSTANTS.MODULE_NAME}.dialogs.warn.itemdata`));
            return;
        }
        // Yea i hate my life
        const actorId = data.actorId;
        let createdItem = undefined;
        // dropping item outside inventory list, but ignore if already owned item
        const targetLi = $(event.target).parents('li')[0];
        let targetType = '';
        const targetCss = getCSSName('sub-header');
        if (targetLi && targetLi.className) {
            if (targetLi.className.trim().indexOf(targetCss) !== -1) {
                targetType = $(targetLi).find('.item-control')[0]?.dataset.type;
            }
            else if (targetLi.className.trim().indexOf('item') !== -1) {
                const itemId = targetLi.dataset.itemId;
                const item = this.object.items.get(itemId);
                targetType = this.inventoryPlus.getItemType(item.data);
            }
        }
        if (!targetType) {
            // No type founded use standard system
            if (!this.actor.isOwner)
                return false;
            const item = await Item.fromDropData(data);
            const itemData = item.toObject();
            // Handle item sorting within the same Actor
            if (await this._isFromSameActor(data))
                return this._onSortItem(event, itemData);
            // Create the owned item
            if (game.settings.get(CONSTANTS.MODULE_NAME, 'enableItemTransfer') &&
                !(await this._isFromSameActor(data)) &&
                !isAlt() &&
                !dragAndDropFromCompendium &&
                dragAndDropFromActorSource) {
                //@ts-ignore
                module.dropActorSheetDataTransferStuff(targetActor, targetActor.sheet, data);
                return;
            }
            else {
                return this._onDropItemCreate(itemData);
            }
        }
        if (targetType == 'feat' || targetType == 'spell' || targetType == 'class' || targetType == 'subclass') {
            if (!this.actor.isOwner)
                return false;
            const item = await Item.fromDropData(data);
            const itemData = item.toObject();
            // Handle item sorting within the same Actor
            if (await this._isFromSameActor(data))
                return this._onSortItem(event, itemData);
            // Create the owned item
            if (game.settings.get(CONSTANTS.MODULE_NAME, 'enableItemTransfer') &&
                !(await this._isFromSameActor(data)) &&
                !isAlt() &&
                !dragAndDropFromCompendium &&
                dragAndDropFromActorSource) {
                //@ts-ignore
                module.dropActorSheetDataTransferStuff(targetActor, targetActor.sheet, data);
                return;
            }
            else {
                return this._onDropItemCreate(itemData);
            }
        }
        if (!targetLi) {
            warn(i18n(`${CONSTANTS.MODULE_NAME}.dialogs.warn.notargethtml`), true);
            if (!this.actor.isOwner)
                return false;
            const item = await Item.fromDropData(data);
            const itemData = item.toObject();
            // Handle item sorting within the same Actor
            if (await this._isFromSameActor(data))
                return this._onSortItem(event, itemData);
            // Create the owned item
            if (game.settings.get(CONSTANTS.MODULE_NAME, 'enableItemTransfer') &&
                !(await this._isFromSameActor(data)) &&
                !isAlt() &&
                !dragAndDropFromCompendium &&
                dragAndDropFromActorSource) {
                //@ts-ignore
                module.dropActorSheetDataTransferStuff(targetActor, targetActor.sheet, data);
                return;
            }
            else {
                return this._onDropItemCreate(itemData);
            }
        }
        if (!targetType || !this.inventoryPlus.customCategorys[targetType]) {
            warn(i18nFormat(`${CONSTANTS.MODULE_NAME}.dialogs.warn.nocategoryfounded`, { targetType: targetType }), true);
            if (!this.actor.isOwner)
                return false;
            const item = await Item.fromDropData(data);
            const itemData = item.toObject();
            // Handle item sorting within the same Actor
            if (await this._isFromSameActor(data))
                return this._onSortItem(event, itemData);
            // Create the owned item
            if (game.settings.get(CONSTANTS.MODULE_NAME, 'enableItemTransfer') &&
                !(await this._isFromSameActor(data)) &&
                !isAlt() &&
                !dragAndDropFromCompendium &&
                dragAndDropFromActorSource) {
                //@ts-ignore
                module.dropActorSheetDataTransferStuff(targetActor, targetActor.sheet, data);
                return;
            }
            else {
                return this._onDropItemCreate(itemData);
            }
        }
        const categoryRef = this.inventoryPlus.customCategorys[targetType];
        if (!categoryRef) {
            error(`Could not retrieve a category with the type '${targetType}'`, true);
            return;
        }
        if (!categoryRef.label) {
            error(`Can't find a label on category with the type '${targetType}'`, true);
            if (!this.actor.isOwner)
                return false;
            const item = await Item.fromDropData(data);
            const itemData = item.toObject();
            // Handle item sorting within the same Actor
            if (await this._isFromSameActor(data))
                return this._onSortItem(event, itemData);
            // Create the owned item
            if (game.settings.get(CONSTANTS.MODULE_NAME, 'enableItemTransfer') &&
                !(await this._isFromSameActor(data)) &&
                !isAlt() &&
                !dragAndDropFromCompendium &&
                dragAndDropFromActorSource) {
                //@ts-ignore
                module.dropActorSheetDataTransferStuff(targetActor, targetActor.sheet, data);
                return;
            }
            else {
                return this._onDropItemCreate(itemData);
            }
        }
        const categoryName = i18n(categoryRef.label);
        // const headerElement = $(<HTMLElement>targetLi.parentElement?.parentElement).find(`h3:contains("${categoryName}")`);
        // dropping new item
        if (actorId !== this.object.id || itemData === undefined) {
            if (!actor.items.get(itemId)) {
                // START WEIGHT CONTROL
                if (API.isCategoryFulled(actor, targetType, itemData)) {
                    warn(i18nFormat(`${CONSTANTS.MODULE_NAME}.dialogs.warn.exceedsmaxweight`, { categoryName: categoryName }), true);
                    return;
                }
                // END WEIGHT CONTROL
                // START ACCEPTABLE TYPE
                if (!API.isAcceptableType(categoryRef, itemData)) {
                    warn(i18nFormat(`${CONSTANTS.MODULE_NAME}.dialogs.warn.noacceptabletype`, {
                        categoryName: categoryName,
                        itemDataType: itemData.type,
                    }), true);
                    return;
                }
                // END itemDataType
                if (!this.actor.isOwner)
                    return false;
                // const item = <Item>await Item.fromDropData(data);
                // const itemData = item.toObject();
                // Handle item sorting within the same Actor
                if (await this._isFromSameActor(data)) {
                    // return this._onSortItem(event, itemData);
                }
                else {
                    // Create the owned item
                    if (game.settings.get(CONSTANTS.MODULE_NAME, 'enableItemTransfer') &&
                        !(await this._isFromSameActor(data)) &&
                        !isAlt() &&
                        !dragAndDropFromCompendium &&
                        dragAndDropFromActorSource) {
                        //@ts-ignore
                        module.dropActorSheetDataTransferStuff(targetActor, targetActor.sheet, data);
                    }
                    else {
                        const items = await this._onDropItemCreate(itemData);
                        createdItem = items[0];
                    }
                }
            }
        }
        if (targetLi === undefined || targetLi.className === undefined) {
            if (actorId === this.object.id) {
                // Do nothing
                //return;
            }
            else {
                if (!actor.items.get(itemId)) {
                    // START WEIGHT CONTROL
                    if (API.isCategoryFulled(actor, targetType, itemData)) {
                        warn(i18nFormat(`${CONSTANTS.MODULE_NAME}.dialogs.warn.exceedsmaxweight`, { categoryName: categoryName }), true);
                        return;
                    }
                    // END WEIGHT CONTROL
                    // START ACCEPTABLE TYPE
                    if (!API.isAcceptableType(categoryRef, itemData)) {
                        warn(i18nFormat(`${CONSTANTS.MODULE_NAME}.dialogs.warn.noacceptabletype`, {
                            categoryName: categoryName,
                            itemDataType: itemData.type,
                        }), true);
                        return;
                    }
                    // END itemDataType
                    if (!this.actor.isOwner)
                        return false;
                    // const item = <Item>await Item.fromDropData(data);
                    // const itemData = item.toObject();
                    // Handle item sorting within the same Actor
                    if (await this._isFromSameActor(data)) {
                        // return this._onSortItem(event, itemData);
                    }
                    else {
                        // Create the owned item
                        if (game.settings.get(CONSTANTS.MODULE_NAME, 'enableItemTransfer') &&
                            !(await this._isFromSameActor(data)) &&
                            !isAlt() &&
                            !dragAndDropFromCompendium &&
                            dragAndDropFromActorSource) {
                            //@ts-ignore
                            module.dropActorSheetDataTransferStuff(targetActor, targetActor.sheet, data);
                        }
                        else {
                            const items = await this._onDropItemCreate(itemData);
                            createdItem = items[0];
                        }
                    }
                }
            }
        }
        // const targetLi = <HTMLLIElement>$(event.target).parents('li')[0];
        // doing actual stuff!!!
        // const itemId = itemData._id;
        let dropedItem = this.object.items.get(itemId);
        if (!dropedItem) {
            if (createdItem) {
                dropedItem = createdItem;
            }
            else {
                warn(i18n(`${CONSTANTS.MODULE_NAME}.dialogs.warn.nodroppeditem`));
                return;
            }
        }
        // changing item list
        let itemType = this.inventoryPlus.getItemType(itemData); // data.data
        if (itemType !== targetType) {
            // START WEIGHT CONTROL
            if (API.isCategoryFulled(actor, targetType, itemData)) {
                warn(i18nFormat(`${CONSTANTS.MODULE_NAME}.dialogs.warn.exceedsmaxweight`, { categoryName: categoryName }), true);
                return;
            }
            // END WEIGHT CONTROL
            // START ACCEPTABLE TYPE
            if (!API.isAcceptableType(categoryRef, itemData)) {
                warn(i18nFormat(`${CONSTANTS.MODULE_NAME}.dialogs.warn.noacceptabletype`, {
                    categoryName: categoryName,
                    itemDataType: itemData.type,
                }), true);
                return;
            }
            // END itemDataType
            await dropedItem.setFlag(CONSTANTS.MODULE_NAME, InventoryPlusFlags.CATEGORY, targetType);
            itemType = targetType;
            /*
            const categoryWeight = this.inventoryPlus.getCategoryItemWeight(targetType);
            //@ts-ignore
            const itemWeight = dropedItem.data.data.weight * dropedItem.data.data.quantity;
            const maxWeight = Number(
              this.inventoryPlus.customCategorys[targetType].maxWeight
                ? this.inventoryPlus.customCategorys[targetType].maxWeight
                : 0,
            );
    
            if (isNaN(maxWeight) || maxWeight <= 0 || maxWeight >= categoryWeight + itemWeight) {
              // await dropedItem.update({ 'flags.inventory-plus.category': targetType });
              await dropedItem.setFlag(CONSTANTS.MODULE_NAME, InventoryPlusFlags.CATEGORY, targetType);
              itemType = targetType;
            } else {
              warn(
                i18nFormat(`${CONSTANTS.MODULE_NAME}.dialogs.warn.exceedsmaxweight`, { categoryName: categoryName }),
                true,
              );
              return;
            }
            */
        }
        // reordering items
        // Get the drag source and its siblings
        const siblings = this.object.items.filter((i) => {
            const type = this.inventoryPlus.getItemType(i.data);
            return type === itemType && i.data._id !== dropedItem.data._id;
        });
        // Get the drop target
        const dropTarget = event.target.closest('.item');
        const targetId = dropTarget ? dropTarget.dataset.itemId : null;
        const target = siblings.find((s) => s.data._id === targetId);
        // Perform the sort
        const sortUpdates = SortingHelpers.performIntegerSort(dropedItem, { target: target, siblings });
        let updateData = sortUpdates.map((u) => {
            const update = u.update;
            update._id = u.target.data._id;
            return update;
        });
        updateData = updateData.filter((i) => {
            return i._id != null && i._id != undefined && i._id != '';
        });
        // Perform the update
        this.object.updateEmbeddedDocuments('Item', updateData);
    }, 'MIXED');
    // Hooks.on(`renderActorSheet5eCharacter`, (app, html, data) => {
    Hooks.on(`renderActorSheet`, (app, html, data) => {
        module.renderActorSheet5eCharacterInventoryPlus(app, html, data);
        module.renderActorSheetEnableInventorySorter(app, html, data);
    });
    Hooks.on('dropActorSheetData', (targetActor, targetSheet, futureItem) => {
        // module.dropActorSheetDataTransferStuff(targetActor, targetSheet, futureItem);
    });
    Hooks.on('preUpdateItem', (item, changes, options, ...args) => {
        module.preUpdateItemInventorySorter(item, changes, options, ...args);
    });
    Hooks.on('createItem', (item, options, userId, ...args) => {
        module.createItemInventorySorter(item, options, userId, ...args);
    });
    Hooks.on('deleteItem', (item, options, userId, ...args) => {
        module.deleteItemInventorySorter(item, options, userId, ...args);
    });
    Hooks.on('updateItem', (item, changes, options, userId) => {
        module.updateItemInventorySorter(item, changes, options, userId);
    });
};
const module = {
    async manageInventoryPlus(targetActor, targetSheet, data) {
        // TODO THE HOOK IS BETTER OF THE WRAPPER INTERCEPTOR...
    },
    async renderActorSheet5eCharacterInventoryPlus(...args) {
        const [app, html, data] = args;
        if (!app.inventoryPlus) {
            const actorEntityTmp = game.actors?.get(data.actor._id);
            app.inventoryPlus = new InventoryPlus();
            app.inventoryPlus.init(actorEntityTmp);
        }
        app.inventoryPlus.addInventoryFunctions(html);
    },
    dropActorSheetDataTransferStuff(targetActor, targetSheet, data) {
        if (!game.settings.get(CONSTANTS.MODULE_NAME, 'enableItemTransfer')) {
            return;
        }
        // if (isAlt()) {
        //   return; // ignore when Alt is pressed to drop.
        // }
        if (targetActor.permission != 3) {
            error("You don't have the permissions to transfer items here", true);
            return;
        }
        if (data.type == 'Item' && data.actorId) {
            if (!targetActor.data._id) {
                warn(`target has no data._id? ${targetActor}`);
                return;
            }
            if (targetActor.data._id == data.actorId) {
                return; // ignore dropping on self
            }
            let sourceSheet;
            if (data.tokenId != null) {
                //game.scenes.get("hyfUtn3VVPnVUpJe").tokens.get("OYwRVJ7crDyid19t").sheet.actor.items
                //@ts-ignore
                sourceSheet = game.scenes?.get(data.sceneId).tokens.get(data.tokenId).sheet;
            }
            else {
                //@ts-ignore
                sourceSheet = game.actors?.get(data.actorId).sheet;
            }
            const sourceActor = game.actors?.get(data.actorId);
            if (sourceActor) {
                /* if both source and target have the same type then allow deleting original item. this is a safety check because some game systems may allow dropping on targets that don't actually allow the GM or player to see the inventory, making the item inaccessible. */
                if (checkCompatible(sourceActor.data.type, targetActor.data.type, data)) {
                    const originalQuantity = data.data.data.quantity;
                    const targetActorId = targetActor.data._id;
                    const sourceActorId = data.actorId;
                    if (game.settings.get(CONSTANTS.MODULE_NAME, 'enableCurrencyTransfer') && data.data.name === 'Currency') {
                        showCurrencyTransferDialog(sourceSheet, targetSheet);
                        return false;
                    }
                    else if (originalQuantity >= 1) {
                        // game.settings.get(CONSTANTS.MODULE_NAME, 'enableItemTransfer') &&
                        showItemTransferDialog(originalQuantity, sourceSheet, targetSheet, data.data._id, data);
                        return false;
                    }
                }
            }
        }
    },
    preUpdateItemInventorySorter(item, changes, options, ...args) {
        if (!game.settings.get(CONSTANTS.MODULE_NAME, 'enableInventorySorter')) {
            return;
        }
        if (changes.sort !== undefined) {
            if (!options.inventorySorterUpdate) {
                const itemSorts = getItemSorts(item.parent);
                const itemSort = itemSorts.get(changes._id);
                if (itemSort) {
                    changes.sort = itemSort.sort;
                }
            }
            if (item.data.sort === changes.sort && Object.keys(changes).length === 2) {
                return false;
            }
        }
    },
    createItemInventorySorter(item, options, userId, ...args) {
        if (!game.settings.get(CONSTANTS.MODULE_NAME, 'enableInventorySorter')) {
            return;
        }
        if (userId === game.userId) {
            delayedSort(item.parent);
        }
    },
    deleteItemInventorySorter(item, options, userId, ...args) {
        if (!game.settings.get(CONSTANTS.MODULE_NAME, 'enableInventorySorter')) {
            return;
        }
        if (userId === game.userId) {
            delayedSort(item.parent);
        }
    },
    updateItemInventorySorter(item, changes, options, userId) {
        if (!game.settings.get(CONSTANTS.MODULE_NAME, 'enableInventorySorter')) {
            return;
        }
        if (userId === game.userId) {
            if (!options.inventorySorterUpdate) {
                delayedSort(item.parent);
            }
        }
    },
    renderActorSheetEnableInventorySorter(actorSheet, html, data) {
        if (!game.settings.get(CONSTANTS.MODULE_NAME, 'enableInventorySorter')) {
            return;
        }
        if (actorSheet?.isEditable) {
            const actor = actorSheet?.actor;
            if (!sortedActors.has(actor.id)) {
                delayedSort(actor);
            }
        }
    },
};
