/**
 * @author Felix Müller
 */
import CONSTANTS from "./constants.js";
import { Category, InventoryPlusFlags, inventoryPlusItemTypeCollection, } from "./inventory-plus-models.js";
import { debug, duplicateExtended, error, getCSSName, i18n, i18nFormat, isStringEquals, is_real_number, warn, } from "./lib/lib.js";
// import ActorSheet5eCharacter from "../../systems/dnd5e/module/actor/sheets/character.js";
export class InventoryPlus {
    static processInventory(app, actor, inventory) {
        if (app.inventoryPlus === undefined) {
            app.inventoryPlus = new InventoryPlus();
            app.inventoryPlus.init(actor);
        }
        return app.inventoryPlus.prepareInventory(inventory);
    }
    init(actor) {
        // , inventory: Category[]
        this.actor = actor;
        this.initCategorys();
    }
    initCategorys() {
        let flagCategorys = (this.actor.getFlag(CONSTANTS.MODULE_NAME, InventoryPlusFlags.CATEGORYS));
        const flagDisableDefaultCategories = false;
        if (flagCategorys === undefined && !flagDisableDefaultCategories) {
            debug(`flagCategory=false && flagDisableDefaultCategories=false`);
            flagCategorys = {
                weapon: {
                    label: 'DND5E.ItemTypeWeaponPl',
                    dataset: { type: 'weapon' },
                    sortFlag: 1000,
                    ignoreWeight: false,
                    maxWeight: 0,
                    ownWeight: 0,
                    collapsed: false,
                    items: [],
                    explicitTypes: inventoryPlusItemTypeCollection.filter((t) => {
                        return t.isInventory;
                    }),
                },
                equipment: {
                    label: 'DND5E.ItemTypeEquipmentPl',
                    dataset: { type: 'equipment' },
                    sortFlag: 2000,
                    ignoreWeight: false,
                    maxWeight: 0,
                    ownWeight: 0,
                    collapsed: false,
                    items: [],
                    explicitTypes: inventoryPlusItemTypeCollection.filter((t) => {
                        return t.isInventory;
                    }),
                },
                consumable: {
                    label: 'DND5E.ItemTypeConsumablePl',
                    dataset: { type: 'consumable' },
                    sortFlag: 3000,
                    ignoreWeight: false,
                    maxWeight: 0,
                    ownWeight: 0,
                    collapsed: false,
                    items: [],
                    explicitTypes: inventoryPlusItemTypeCollection.filter((t) => {
                        return t.isInventory;
                    }),
                },
                tool: {
                    label: 'DND5E.ItemTypeToolPl',
                    dataset: { type: 'tool' },
                    sortFlag: 4000,
                    ignoreWeight: false,
                    maxWeight: 0,
                    ownWeight: 0,
                    collapsed: false,
                    items: [],
                    explicitTypes: inventoryPlusItemTypeCollection.filter((t) => {
                        return t.isInventory;
                    }),
                },
                backpack: {
                    label: 'DND5E.ItemTypeContainerPl',
                    dataset: { type: 'backpack' },
                    sortFlag: 5000,
                    ignoreWeight: false,
                    maxWeight: 0,
                    ownWeight: 0,
                    collapsed: false,
                    items: [],
                    explicitTypes: inventoryPlusItemTypeCollection.filter((t) => {
                        return t.isInventory;
                    }),
                },
                loot: {
                    label: 'DND5E.ItemTypeLootPl',
                    dataset: { type: 'loot' },
                    sortFlag: 6000,
                    ignoreWeight: false,
                    maxWeight: 0,
                    ownWeight: 0,
                    collapsed: false,
                    items: [],
                    explicitTypes: inventoryPlusItemTypeCollection.filter((t) => {
                        return t.isInventory;
                    }),
                },
            };
        }
        else if (flagCategorys && !flagDisableDefaultCategories) {
            debug(`flagCategory=true && flagDisableDefaultCategories=false`);
            const categoryWeapon = flagCategorys['weapon'];
            if (!categoryWeapon) {
                flagCategorys['weapon'] = {
                    label: 'DND5E.ItemTypeWeaponPl',
                    dataset: { type: 'weapon' },
                    sortFlag: 1000,
                    ignoreWeight: false,
                    maxWeight: 0,
                    ownWeight: 0,
                    collapsed: false,
                    items: [],
                    explicitTypes: inventoryPlusItemTypeCollection.filter((t) => {
                        return t.isInventory;
                    }),
                };
            }
            const categoryEquipment = flagCategorys['equipment'];
            if (!categoryEquipment) {
                flagCategorys['equipment'] = {
                    label: 'DND5E.ItemTypeEquipmentPl',
                    dataset: { type: 'equipment' },
                    sortFlag: 2000,
                    ignoreWeight: false,
                    maxWeight: 0,
                    ownWeight: 0,
                    collapsed: false,
                    items: [],
                    explicitTypes: inventoryPlusItemTypeCollection.filter((t) => {
                        return t.isInventory;
                    }),
                };
            }
            const categoryConsumable = flagCategorys['consumable'];
            if (!categoryConsumable) {
                flagCategorys['consumable'] = {
                    label: 'DND5E.ItemTypeConsumablePl',
                    dataset: { type: 'consumable' },
                    sortFlag: 3000,
                    ignoreWeight: false,
                    maxWeight: 0,
                    ownWeight: 0,
                    collapsed: false,
                    items: [],
                    explicitTypes: inventoryPlusItemTypeCollection.filter((t) => {
                        return t.isInventory;
                    }),
                };
            }
            const categoryTool = flagCategorys['tool'];
            if (!categoryTool) {
                flagCategorys['tool'] = {
                    label: 'DND5E.ItemTypeToolPl',
                    dataset: { type: 'tool' },
                    sortFlag: 4000,
                    ignoreWeight: false,
                    maxWeight: 0,
                    ownWeight: 0,
                    collapsed: false,
                    items: [],
                    explicitTypes: inventoryPlusItemTypeCollection.filter((t) => {
                        return t.isInventory;
                    }),
                };
            }
            const categoryBackpack = flagCategorys['backpack'];
            if (!categoryBackpack) {
                flagCategorys['backpack'] = {
                    label: 'DND5E.ItemTypeContainerPl',
                    dataset: { type: 'backpack' },
                    sortFlag: 5000,
                    ignoreWeight: false,
                    maxWeight: 0,
                    ownWeight: 0,
                    collapsed: false,
                    items: [],
                    explicitTypes: inventoryPlusItemTypeCollection.filter((t) => {
                        return t.isInventory;
                    }),
                };
            }
            const categoryLoot = flagCategorys['loot'];
            if (!categoryLoot) {
                flagCategorys['loot'] = {
                    label: 'DND5E.ItemTypeLootPl',
                    dataset: { type: 'loot' },
                    sortFlag: 6000,
                    ignoreWeight: false,
                    maxWeight: 0,
                    ownWeight: 0,
                    collapsed: false,
                    items: [],
                    explicitTypes: inventoryPlusItemTypeCollection.filter((t) => {
                        return t.isInventory;
                    }),
                };
            }
        }
        else if (flagCategorys && flagDisableDefaultCategories) {
            debug(`flagCategory=true && flagDisableDefaultCategories=true`);
            for (const key in flagCategorys) {
                const category = flagCategorys[key];
                if (category && !category?.label) {
                    continue;
                }
                if (isStringEquals(i18n(category?.label), i18n('DND5E.ItemTypeWeaponPl'))) {
                    delete flagCategorys[key];
                }
                if (isStringEquals(i18n(category?.label), i18n('DND5E.ItemTypeEquipmentPl'))) {
                    delete flagCategorys[key];
                }
                if (isStringEquals(i18n(category?.label), i18n('DND5E.ItemTypeConsumablePl'))) {
                    delete flagCategorys[key];
                }
                if (isStringEquals(i18n(category?.label), i18n('DND5E.ItemTypeToolPl'))) {
                    delete flagCategorys[key];
                }
                if (isStringEquals(i18n(category?.label), i18n('DND5E.ItemTypeContainerPl'))) {
                    delete flagCategorys[key];
                }
                if (isStringEquals(i18n(category?.label), i18n('DND5E.ItemTypeLootPl'))) {
                    delete flagCategorys[key];
                }
            }
        }
        else {
            debug(`flagCategory=false && flagDisableDefaultCategories=true`);
            if (!flagCategorys) {
                flagCategorys = {};
            }
        }
        // Little trick for filter the undefined values
        // https://stackoverflow.com/questions/51624641/how-to-filter-records-based-on-the-status-value-in-javascript-object
        const filterJSON = Object.keys(flagCategorys)
            .filter(function (key) {
            const entry = flagCategorys[key];
            return entry != undefined && entry != null && entry.label;
        })
            .reduce((res, key) => ((res[key] = flagCategorys[key]), res), {});
        this.customCategorys = duplicateExtended(filterJSON);
        this.applySortKey();
    }
    addInventoryFunctions(html) {
        /*
         *  add remove default categories
         */
        const flagDisableDefaultCategories = true; // IS ALWAYS FALSE FOR NOW
        const labelDialogDisableDefaultCategories = flagDisableDefaultCategories
            ? i18n(`${CONSTANTS.MODULE_NAME}.inv-plus-dialog.reenabledefaultcategories`)
            : i18n(`${CONSTANTS.MODULE_NAME}.inv-plus-dialog.removedefaultcategories`);
        const iconClass = flagDisableDefaultCategories ? `fa-plus-square` : `fa-minus-square`;
        // ONly gm can do this
        if (game.user?.isGM) {
            const status = flagDisableDefaultCategories
                ? i18n(`inventory-plus.inv-plus-dialog.removedefaulcategorieswarnmessagereenable`)
                : i18n(`inventory-plus.inv-plus-dialog.removedefaulcategorieswarnmessagedisable`);
            const msg = i18nFormat(`inventory-plus.inv-plus-dialog.removedefaulcategorieswarnmessage`, { status: status });
            const removeDefaultCategoriesBtn = $(`<a class="custom-category"><i class="fas ${iconClass}"></i>${labelDialogDisableDefaultCategories}</a>`).click(async (ev) => {
                const template = await renderTemplate(`modules/${CONSTANTS.MODULE_NAME}/templates/restoreDefaultCategoriesDialog.hbs`, {
                    msg: msg,
                });
                const d = new Dialog({
                    title: i18n(`${CONSTANTS.MODULE_NAME}.inv-plus-dialog.removedefaultcategories`),
                    content: template,
                    buttons: {
                        accept: {
                            icon: '<i class="fas fa-check"></i>',
                            label: i18n(`${CONSTANTS.MODULE_NAME}.inv-plus-dialog.accept`),
                            callback: async (html) => {
                                const f = flagDisableDefaultCategories && String(flagDisableDefaultCategories) === 'true' ? true : false;
                                if (!f) {
                                    const physicalItems = ['weapon', 'equipment', 'consumable', 'tool', 'backpack', 'loot'];
                                    for (const catType of physicalItems) {
                                        this.removeCategory(catType);
                                    }
                                }
                                else {
                                    const categoryWeapon = this.customCategorys['weapon'];
                                    if (!categoryWeapon) {
                                        this.customCategorys['weapon'] = {
                                            label: 'DND5E.ItemTypeWeaponPl',
                                            dataset: { type: 'weapon' },
                                            sortFlag: 1000,
                                            ignoreWeight: false,
                                            maxWeight: 0,
                                            ownWeight: 0,
                                            collapsed: false,
                                            items: [],
                                            explicitTypes: inventoryPlusItemTypeCollection.filter((t) => {
                                                return t.isInventory;
                                            }),
                                        };
                                    }
                                    const categoryEquipment = this.customCategorys['equipment'];
                                    if (!categoryEquipment) {
                                        this.customCategorys['equipment'] = {
                                            label: 'DND5E.ItemTypeEquipmentPl',
                                            dataset: { type: 'equipment' },
                                            sortFlag: 2000,
                                            ignoreWeight: false,
                                            maxWeight: 0,
                                            ownWeight: 0,
                                            collapsed: false,
                                            items: [],
                                            explicitTypes: inventoryPlusItemTypeCollection.filter((t) => {
                                                return t.isInventory;
                                            }),
                                        };
                                    }
                                    const categoryConsumable = this.customCategorys['consumable'];
                                    if (!categoryConsumable) {
                                        this.customCategorys['consumable'] = {
                                            label: 'DND5E.ItemTypeConsumablePl',
                                            dataset: { type: 'consumable' },
                                            sortFlag: 3000,
                                            ignoreWeight: false,
                                            maxWeight: 0,
                                            ownWeight: 0,
                                            collapsed: false,
                                            items: [],
                                            explicitTypes: inventoryPlusItemTypeCollection.filter((t) => {
                                                return t.isInventory;
                                            }),
                                        };
                                    }
                                    const categoryTool = this.customCategorys['tool'];
                                    if (!categoryTool) {
                                        this.customCategorys['tool'] = {
                                            label: 'DND5E.ItemTypeToolPl',
                                            dataset: { type: 'tool' },
                                            sortFlag: 4000,
                                            ignoreWeight: false,
                                            maxWeight: 0,
                                            ownWeight: 0,
                                            collapsed: false,
                                            items: [],
                                            explicitTypes: inventoryPlusItemTypeCollection.filter((t) => {
                                                return t.isInventory;
                                            }),
                                        };
                                    }
                                    const categoryBackpack = this.customCategorys['backpack'];
                                    if (!categoryBackpack) {
                                        this.customCategorys['backpack'] = {
                                            label: 'DND5E.ItemTypeContainerPl',
                                            dataset: { type: 'backpack' },
                                            sortFlag: 5000,
                                            ignoreWeight: false,
                                            maxWeight: 0,
                                            ownWeight: 0,
                                            collapsed: false,
                                            items: [],
                                            explicitTypes: inventoryPlusItemTypeCollection.filter((t) => {
                                                return t.isInventory;
                                            }),
                                        };
                                    }
                                    const categoryLoot = this.customCategorys['loot'];
                                    if (!categoryLoot) {
                                        this.customCategorys['loot'] = {
                                            label: 'DND5E.ItemTypeLootPl',
                                            dataset: { type: 'loot' },
                                            sortFlag: 6000,
                                            ignoreWeight: false,
                                            maxWeight: 0,
                                            ownWeight: 0,
                                            collapsed: false,
                                            items: [],
                                            explicitTypes: inventoryPlusItemTypeCollection.filter((t) => {
                                                return t.isInventory;
                                            }),
                                        };
                                    }
                                    this.saveCategorys();
                                }
                            },
                        },
                        cancel: {
                            icon: '<i class="fas fa-times"></i>',
                            label: i18n(`${CONSTANTS.MODULE_NAME}.inv-plus-dialog.cancel`),
                        },
                    },
                    default: 'cancel',
                });
                d.render(true);
            });
            html.find('.inventory .filter-list').prepend(removeDefaultCategoriesBtn);
        }
        /*
         *  create custom category
         */
        const addCategoryBtn = $(`<a class="custom-category"><i class="fas fa-plus"></i>${i18n(`${CONSTANTS.MODULE_NAME}.inv-plus-dialog.addcustomcategory`)}</a>`).click(async (ev) => {
            const explicitTypesFromList = inventoryPlusItemTypeCollection.filter((t) => {
                return t.isInventory;
            });
            const template = await renderTemplate(`modules/${CONSTANTS.MODULE_NAME}/templates/categoryDialog.hbs`, {
                explicitTypes: explicitTypesFromList,
            });
            const d = new Dialog({
                title: i18n(`${CONSTANTS.MODULE_NAME}.inv-plus-dialog.creatingnewinventorycategory`),
                content: template,
                buttons: {
                    accept: {
                        icon: '<i class="fas fa-check"></i>',
                        label: i18n(`${CONSTANTS.MODULE_NAME}.inv-plus-dialog.accept`),
                        callback: async (html) => {
                            const input = html.find('input');
                            const selectExplicitTypes = $(html.find('select[name="explicitTypes"')[0]);
                            this.createCategory(input, selectExplicitTypes); // ,selectDefaultType
                        },
                    },
                    cancel: {
                        icon: '<i class="fas fa-times"></i>',
                        label: i18n(`${CONSTANTS.MODULE_NAME}.inv-plus-dialog.cancel`),
                    },
                },
                render: (html) => {
                    $(html.find(`select[name="explicitTypes"]`)[0])
                        //@ts-ignore
                        .SumoSelect({
                        placeholder: 'Select item inventory type...',
                        triggerChangeCombined: true,
                    });
                },
                default: 'cancel',
            });
            d.render(true);
        });
        html.find('.inventory .filter-list').prepend(addCategoryBtn);
        /*
         *  add removal function
         */
        const createBtns = html.find('.inventory .item-create');
        for (const createBtn of createBtns) {
            const type = createBtn.dataset.type;
            // Filter for only invenotry items
            // const physicalItems = ['weapon', 'equipment', 'consumable', 'tool', 'backpack', 'loot'];
            // if (physicalItems.indexOf(type) === -1) {
            const parent = createBtn.parentNode;
            const removeCategoryBtn = $(`<div class="item-controls flexrow">
        <a class="item-control item-create" 
          title="${i18n('DND5E.ItemCreate')}" 
          data-type="${type}">
          <i class="fas fa-plus"></i> ${i18n('DND5E.Add')}</a>
        <a class="item-control remove-category" 
            title="${i18n(`${CONSTANTS.MODULE_NAME}.inv-plus-dialog.deletecategory`)}"
            data-type="${type}">
            <i class="fas fa-minus"></i>${i18n(`${CONSTANTS.MODULE_NAME}.inv-plus-dialog.deletecategoryprefix`)}</a>
        </div>`);
            removeCategoryBtn.find('.item-create').click((ev) => {
                ev.preventDefault();
                const catType = ev.target.dataset.type || ev.currentTarget.dataset.type;
                this._onItemCreate(ev, catType);
            });
            removeCategoryBtn.find('.remove-category').click(async (ev) => {
                ev.preventDefault();
                const catType = ev.target.dataset.type || ev.currentTarget.dataset.type;
                //this.removeCategory(catType);
                const status = flagDisableDefaultCategories
                    ? i18n(`inventory-plus.inv-plus-dialog.removedefaulcategorieswarnmessagereenable`)
                    : i18n(`inventory-plus.inv-plus-dialog.removedefaulcategorieswarnmessagedisable`);
                const msg = i18nFormat(`inventory-plus.inv-plus-dialog.removedefaulcategorieswarnmessage`, { status: status });
                const template = await renderTemplate(`modules/${CONSTANTS.MODULE_NAME}/templates/removeCategoryDialog.hbs`, {
                    msg: msg,
                });
                const d = new Dialog({
                    title: i18n(`${CONSTANTS.MODULE_NAME}.inv-plus-dialog.deletecategory`),
                    content: template,
                    buttons: {
                        accept: {
                            icon: '<i class="fas fa-check"></i>',
                            label: i18n(`${CONSTANTS.MODULE_NAME}.inv-plus-dialog.accept`),
                            callback: async (html) => {
                                this.removeCategory(catType);
                            },
                        },
                        cancel: {
                            icon: '<i class="fas fa-times"></i>',
                            label: i18n(`${CONSTANTS.MODULE_NAME}.inv-plus-dialog.cancel`),
                        },
                    },
                    default: 'cancel',
                });
                d.render(true);
            });
            //@ts-ignore
            parent.innerHTML = '';
            $(parent).append(removeCategoryBtn);
            // }
        }
        /*
         *  add extra header functions
         */
        const targetCss = `.inventory .${getCSSName('sub-header')}`;
        const headers = html.find(targetCss);
        for (const headerTmp of headers) {
            const header = $(headerTmp);
            const type = header.find('.item-control')[0].dataset.type;
            const extraStuff = $('<div class="inv-plus-stuff flexrow"></div>');
            header.find('h3').after(extraStuff);
            if (this.customCategorys[type] === undefined) {
                warn(i18nFormat(`${CONSTANTS.MODULE_NAME}.dialogs.warn.nocategoryfoundbytype`, { type: type }));
                return;
            }
            const currentCategory = this.customCategorys[type];
            if (!currentCategory.explicitTypes || currentCategory.explicitTypes.length === 0) {
                currentCategory.explicitTypes = inventoryPlusItemTypeCollection.filter((t) => {
                    return t.isInventory;
                });
            }
            // ===================
            // toggle item visibility
            // ===================
            const arrow = currentCategory?.collapsed === true ? 'right' : 'down';
            const toggleBtn = $(`<a class="toggle-collapse"><i class="fas fa-caret-${arrow}"></i></a>`).click((ev) => {
                currentCategory.collapsed = !currentCategory?.collapsed;
                this.saveCategorys();
            });
            header.find('h3').before(toggleBtn);
            // ===================
            // reorder category
            // ===================
            if (this.getLowestSortFlag() !== currentCategory.sortFlag) {
                const upBtn = $(`<a class="inv-plus-stuff shuffle-up" title="Move category up"><i class="fas fa-chevron-up"></i></a>`).click(() => this.changeCategoryOrder(type, true));
                extraStuff.append(upBtn);
            }
            if (this.getHighestSortFlag() !== currentCategory.sortFlag) {
                const downBtn = $(`<a class="inv-plus-stuff shuffle-down" title="Move category down"><i class="fas fa-chevron-down"></i></a>`).click(() => this.changeCategoryOrder(type, false));
                extraStuff.append(downBtn);
            }
            // ================
            // edit category
            // ===============
            const editCategoryBtn = $(`<a class="inv-plus-stuff customize-category" data-type="${type}"><i class="fas fa-edit"></i></a>`).click(async (ev) => {
                const catTypeTmp = ev.target.dataset.type || ev.currentTarget.dataset.type;
                const currentCategoryTmp = duplicateExtended(this.customCategorys[catTypeTmp]);
                currentCategoryTmp.label = i18n(currentCategoryTmp.label);
                const template = await renderTemplate(`modules/${CONSTANTS.MODULE_NAME}/templates/categoryDialog.hbs`, currentCategoryTmp);
                const d = new Dialog({
                    title: i18n(`${CONSTANTS.MODULE_NAME}.inv-plus-dialog.editinventorycategory`),
                    content: template,
                    buttons: {
                        accept: {
                            icon: '<i class="fas fa-check"></i>',
                            label: i18n(`${CONSTANTS.MODULE_NAME}.inv-plus-dialog.accept`),
                            callback: async (html) => {
                                const inputs = html.find('input');
                                for (const input of inputs) {
                                    const value = input.type === 'checkbox' ? input.checked : input.value;
                                    if (input.dataset.dtype === 'Number') {
                                        const valueN = Number(value) > 0 ? Number(value) : 0;
                                        currentCategory[input.name] = valueN;
                                    }
                                    else {
                                        currentCategory[input.name] = value;
                                    }
                                }
                                const currentTypeSelectedS = ($(html.find('select[name="explicitTypes"')[0])?.val());
                                if (!currentTypeSelectedS || currentTypeSelectedS.length === 0) {
                                    currentCategory.explicitTypes = [];
                                }
                                else if (currentTypeSelectedS.length === 1 && !currentTypeSelectedS[0]) {
                                    const newArr = currentCategory.explicitTypes.map((obj) => {
                                        return { ...obj, isSelected: false };
                                    });
                                    currentCategory.explicitTypes = newArr;
                                }
                                else {
                                    const newArr = currentCategory.explicitTypes.map((obj) => {
                                        if (currentTypeSelectedS.includes(obj.id)) {
                                            return { ...obj, isSelected: true };
                                        }
                                        else {
                                            return { ...obj, isSelected: false };
                                        }
                                    });
                                    currentCategory.explicitTypes = newArr;
                                }
                                this.customCategorys[catTypeTmp] = currentCategory;
                                this.saveCategorys();
                            },
                        },
                        cancel: {
                            icon: '<i class="fas fa-times"></i>',
                            label: i18n(`${CONSTANTS.MODULE_NAME}.inv-plus-dialog.cancel`),
                        },
                    },
                    render: (html) => {
                        $(html.find(`select[name="explicitTypes"]`)[0])
                            //@ts-ignore
                            .SumoSelect({
                            placeholder: 'Select item inventory type...',
                            triggerChangeCombined: true,
                        });
                    },
                    default: 'cancel',
                });
                d.render(true);
            });
            extraStuff.append(editCategoryBtn);
            // hide collapsed category items
            if (currentCategory.collapsed === true) {
                header.next().hide();
            }
            let icon = ``;
            // show type of category
            //const physicalItems = ['weapon', 'equipment', 'consumable', 'tool', 'backpack', 'loot']
            const enabledExplicitTypes = currentCategory.explicitTypes.filter((i) => {
                return i.isSelected;
            });
            if (enabledExplicitTypes.length > 0) {
                for (const explicitType of enabledExplicitTypes) {
                    // None
                    // if(!explicitType.id || explicitType.id === ''){
                    //   icon = icon+`<i class="fas fa-times-circle"></i>`;
                    // }
                    // Weapon
                    if (explicitType.id === 'weapon') {
                        icon = icon + `<i class="fas fa-bomb"></i>`;
                    }
                    // Equipment
                    if (explicitType.id === 'equipment') {
                        icon = icon + `<i class="fas fa-vest"></i>`;
                    }
                    // Consumable
                    if (explicitType.id === 'consumable') {
                        icon = icon + `<i class="fas fa-hamburger"></i>`;
                    }
                    // Tool
                    if (explicitType.id === 'tool') {
                        icon = icon + `<i class="fas fa-scroll"></i>`;
                    }
                    // Backpack
                    if (explicitType.id === 'backpack') {
                        icon = icon + `<i class="fas fa-toolbox"></i>`;
                    }
                    // Loot
                    if (explicitType.id === 'loot') {
                        icon = icon + `<i class="fas fa-box"></i>`;
                    }
                }
            }
            if (currentCategory.maxWeight > 0) {
                if (currentCategory.ignoreWeight) {
                    icon = icon + `<i class="fas fa-feather"></i>`;
                }
                else if (currentCategory.ownWeight > 0) {
                    icon = icon + `<i class="fas fa-weight-hanging"></i>`;
                }
                else {
                    icon = icon + `<i class="fas fa-balance-scale-right"></i>`;
                }
                const weight = this.getCategoryItemWeight(type);
                const weightUnit = game.settings.get('dnd5e', 'metricWeightUnits')
                    ? game.i18n.localize('DND5E.AbbreviationKgs')
                    : game.i18n.localize('DND5E.AbbreviationLbs');
                const weightValue = `(${weight}/${currentCategory.maxWeight} ${weightUnit})`;
                const weightString = $(`<label class="category-weight"> ${icon} ${weightValue}</label>`);
                header.find('h3').append(weightString);
            }
            else {
                const weight = this.getCategoryItemWeight(type);
                const weightUnit = game.settings.get('dnd5e', 'metricWeightUnits')
                    ? game.i18n.localize('DND5E.AbbreviationKgs')
                    : game.i18n.localize('DND5E.AbbreviationLbs');
                const weightValue = `(${weight}/${currentCategory.maxWeight} ${weightUnit})`;
                const weightString = $(`<label class="category-weight"> ${icon}</label>`);
                header.find('h3').append(weightString);
            }
        }
    }
    prepareInventory(inventory) {
        const sections = duplicateExtended(this.customCategorys);
        for (const id in sections) {
            sections[id].items = [];
        }
        for (const section of inventory) {
            for (const item of section.items) {
                let type = this.getItemType(item);
                if (sections[type] === undefined) {
                    type = item.type;
                }
                if (sections[type]) {
                    sections[type].items?.push(item);
                }
            }
        }
        // sort items within sections
        for (const id in sections) {
            const section = sections[id];
            section.items?.sort((a, b) => {
                return a.sort - b.sort;
            });
        }
        return sections;
    }
    createCategory(inputs, selectExplicitTypes) {
        // ,selectDefaultType:JQuery<HTMLElement>
        const newCategory = new Category();
        for (const input of inputs) {
            const value = input.type === 'checkbox' ? input.checked : input.value;
            if (input.dataset.dtype === 'Number') {
                const valueN = Number(value) > 0 ? Number(value) : 0;
                newCategory[input.name] = valueN;
            }
            else {
                newCategory[input.name] = value;
            }
        }
        const typesSelected = selectExplicitTypes.val();
        const explicitTypesFromListTmp = [];
        const explicitTypesFromList = inventoryPlusItemTypeCollection.filter((t) => {
            const t2 = duplicateExtended(t);
            if (t2.isInventory && typesSelected.includes(t2.id)) {
                t2.isSelected = true;
                explicitTypesFromListTmp.push(t2);
            }
        });
        newCategory.explicitTypes = explicitTypesFromListTmp;
        if (newCategory.label === undefined || newCategory.label === '') {
            error(`Could not create Category as no name was specified`, true);
            return;
        }
        const key = this.generateCategoryId();
        newCategory.dataset = { type: key };
        newCategory.collapsed = false;
        newCategory.sortFlag = this.getHighestSortFlag() + 1000;
        this.customCategorys[key] = newCategory;
        this.saveCategorys();
    }
    async removeCategory(catType) {
        //const catType = <string>ev.target.dataset.type || <string>ev.currentTarget.dataset.type;
        const changedItems = [];
        for (const item of this.actor.items) {
            const type = this.getItemType(item.data);
            if (type === catType) {
                //await item.unsetFlag(CONSTANTS.MODULE_NAME, InventoryPlusFlag.CATEGORY);
                changedItems.push({
                    _id: item.id,
                    flags: {
                        'inventory-plus': null,
                    },
                });
            }
        }
        //@ts-ignore
        await this.actor.updateEmbeddedDocuments('Item', changedItems);
        delete this.customCategorys[catType];
        const deleteKey = `-=${catType}`;
        await this.actor.setFlag(CONSTANTS.MODULE_NAME, InventoryPlusFlags.CATEGORYS, { [deleteKey]: null });
    }
    changeCategoryOrder(movedType, up) {
        let targetType = movedType;
        let currentSortFlag = 0;
        if (!up)
            currentSortFlag = 999999999;
        for (const id in this.customCategorys) {
            const currentCategory = this.customCategorys[id];
            if (up) {
                if (id !== movedType &&
                    currentCategory.sortFlag < this.customCategorys[movedType].sortFlag &&
                    currentCategory.sortFlag > currentSortFlag) {
                    targetType = id;
                    currentSortFlag = currentCategory.sortFlag;
                }
            }
            else {
                if (id !== movedType &&
                    currentCategory.sortFlag > this.customCategorys[movedType].sortFlag &&
                    currentCategory.sortFlag < currentSortFlag) {
                    targetType = id;
                    currentSortFlag = currentCategory.sortFlag;
                }
            }
        }
        if (movedType !== targetType) {
            const oldMovedSortFlag = this.customCategorys[movedType]?.sortFlag;
            const newMovedSortFlag = currentSortFlag;
            this.customCategorys[movedType].sortFlag = newMovedSortFlag;
            this.customCategorys[targetType].sortFlag = oldMovedSortFlag;
            this.applySortKey();
            this.saveCategorys();
        }
    }
    applySortKey() {
        const sortedCategorys = {};
        const keys = Object.keys(this.customCategorys);
        keys.sort((a, b) => {
            return this.customCategorys[a]?.sortFlag - this.customCategorys[b]?.sortFlag;
        });
        for (const key of keys) {
            sortedCategorys[key] = this.customCategorys[key];
        }
        this.customCategorys = sortedCategorys;
    }
    getHighestSortFlag() {
        let highest = 0;
        for (const id in this.customCategorys) {
            const cat = this.customCategorys[id];
            if (!cat) {
                warn(`Can't find the category with id '${id}'`, true);
                return highest;
            }
            if (cat.sortFlag > highest) {
                highest = cat.sortFlag;
            }
        }
        return highest;
    }
    getLowestSortFlag() {
        let lowest = 999999999;
        for (const id in this.customCategorys) {
            const cat = this.customCategorys[id];
            if (cat.sortFlag < lowest) {
                lowest = cat.sortFlag;
            }
        }
        return lowest;
    }
    generateCategoryId() {
        let id = '';
        let iterations = 100;
        do {
            id = Math.random().toString(36).substring(7);
            iterations--;
        } while (this.customCategorys[id] !== undefined && iterations > 0 && id.length >= 5);
        return id;
    }
    getItemType(item) {
        let type = getProperty(item, `flags.${CONSTANTS.MODULE_NAME}.${InventoryPlusFlags.CATEGORY}`);
        if (type === undefined || this.customCategorys[type] === undefined) {
            type = item.type;
        }
        // 0.5.4 only thing i touched, this broke everything ????
        //if (this.customCategorys[type] && this.customCategorys[type]?.dataset.type != item.type) {
        //  return item.type;
        //}
        return type;
    }
    getCategoryItemWeight(type) {
        let totalCategoryWeight = 0;
        for (const i of this.actor.items) {
            if (type === this.getItemType(i.data)) {
                //@ts-ignore
                const q = i.data.data.quantity;
                //@ts-ignore
                const w = i.data.data.weight;
                let eqpMultiplyer = 1;
                if (game.settings.get(CONSTANTS.MODULE_NAME, 'enableEquipmentMultiplier')) {
                    eqpMultiplyer = game.settings.get(CONSTANTS.MODULE_NAME, 'equipmentMultiplier') || 1;
                }
                //@ts-ignore
                const e = i.data.data.equipped ? eqpMultiplyer : 1;
                if (is_real_number(w) && is_real_number(q)) {
                    //@ts-ignore
                    totalCategoryWeight += w * q * e;
                }
                else {
                    debug(`The item '${i.name}', on category '${type}', on actor ${this.actor?.name} has not valid weight or quantity `);
                }
            }
        }
        return totalCategoryWeight.toNearest(0.1);
    }
    // static getCSSName(element) {
    //   const version = <string[]>game.system.data.version.split('.');
    //   if (element === 'sub-header') {
    //     if (Number(version[0]) == 0 && Number(version[1]) <= 9 && Number(version[2]) <= 8) {
    //       return 'inventory-header';
    //     } else {
    //       return 'items-header';
    //     }
    //   }
    // }
    async saveCategorys() {
        await this.actor.setFlag(CONSTANTS.MODULE_NAME, InventoryPlusFlags.CATEGORYS, this.customCategorys);
    }
    /**
     * Handle creating a new Owned Item for the actor using initial data defined in the HTML dataset.
     * @param {Event} event          The originating click event.
     * @returns {Promise<Item5e[]>}  The newly created item.
     * @private
     */
    async _onItemCreate(event, type) {
        event.preventDefault();
        const header = event.currentTarget;
        // Check to make sure the newly created class doesn't take player over level cap
        //@ts-ignore
        if (type === 'class' && this.actor.data.data.details.level + 1 > CONFIG.DND5E.maxLevel) {
            return ui.notifications.error(game.i18n.format('DND5E.MaxCharacterLevelExceededWarn', 
            //@ts-ignore
            { max: CONFIG.DND5E.maxLevel }));
        }
        let myName = '';
        const physicalItems = ['weapon', 'equipment', 'consumable', 'tool', 'backpack', 'loot'];
        let itemTypeTmp = '';
        if (physicalItems.includes(type.toLowerCase())) {
            myName = game.i18n.format('DND5E.ItemNew', { type: game.i18n.localize(`DND5E.ItemType${type.capitalize()}`) });
            itemTypeTmp = type;
        }
        else {
            const defaultType = this.customCategorys[type]?.explicitTypes.filter((i) => {
                return i.isSelected && i.isInventory;
            })[0];
            if (!defaultType.id) {
                itemTypeTmp = 'weapon';
            }
            else {
                itemTypeTmp = defaultType.id;
            }
            myName = game.i18n.format('DND5E.ItemNew', {
                type: game.i18n.localize(`DND5E.ItemType${itemTypeTmp.capitalize()}`),
            });
        }
        const itemData = {
            name: myName,
            type: itemTypeTmp,
            data: foundry.utils.deepClone(header.dataset),
        };
        delete itemData.data.type;
        const items = await this.actor.createEmbeddedDocuments('Item', [itemData]);
        const dropedItem = items[0];
        await dropedItem.setFlag(CONSTANTS.MODULE_NAME, InventoryPlusFlags.CATEGORY, type);
    }
}
