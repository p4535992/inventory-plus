const CONSTANTS = {
    MODULE_NAME: 'inventory-plus',
    PATH: `modules/inventory-plus/`,
};
CONSTANTS.PATH = `modules/${CONSTANTS.MODULE_NAME}/`;
export default CONSTANTS;
